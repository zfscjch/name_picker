# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  [[CMakeFiles\name_picker_autogen.dir\AutogenUsed.txt]]
  [[CMakeFiles\name_picker_autogen.dir\ParseCache.txt]]
  "name_picker_autogen"
  )
endif()
